/*Question 6:
Rewrite the function using '?' or '||'
Write a loop which prompts for a number greater than 100. 
If the visitor enters another number – ask them to input again.
The loop must ask for a number until either the visitor enters a number greater than 100 or cancels the
input/enters an empty line.
Here we can assume that the visitor only inputs numbers. 
There’s no need to implement a special
handling for a non-numeric input in this task.*/

const prompt=require('prompt-sync')();
const confirm = require('prompt-confirm');

a=prompt("Enter your age");
age=Number(a);
console.log("CheckAge",checkAge(age));

function checkAge(age) {
  if (age > 18) {
    return true;
  } else {
    return new confirm('Did?');
  }
}