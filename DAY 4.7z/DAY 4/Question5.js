/*Question 5:
You are managing a sales department for your company, you want to reward your employees
 based on the sales made by them during the year.
The criteria is as follows:
1. Sales from 0-5000 : 2%
2. Sales from 5001 - 10000 : 5%
3. Sales from 10001 - 20000 : 7%
4. Above 20000 - 10%
Then log the total commission earned by him.*/

const prompt=require('prompt-sync')();
sales=prompt("Enter the sales during this year");
s=Number(sales);
if(s>=0 && s<=5000)
{
comm=(s/100)*2;
}
else if(s>=5001 && s<=10000)
{
comm=(s/100)*5;
}
else if(s>=10001 && s<=20000)
{
comm=(s/100)*7;
}
else if(s>20000)
{
comm=(s/100)*10;
}
else
{
comm="INVALID SALES DATA";
}
console.log("The total commission earned : "+comm);
