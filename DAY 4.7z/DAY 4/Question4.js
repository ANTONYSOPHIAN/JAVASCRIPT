/*Question 4:
Make a Calculator in Javascript which can do operations as Addtion, Subtraction, Multiplication, Division,
Square root, Percentage.*/

const prompt=require('prompt-sync')();
a=prompt("Enter First Value");
console.log("+ |" + " - |" + " * |"  +" / |"+ " r |" + " % ");
c=prompt("Press the any arithmetic keys");
Result=0;
switch(c)
{
case '+':
b=prompt("Enter Second Value");
Result+=Number(a)+Number(b);
break;
case '-':
b=prompt("Enter Second Value");
Result+=Number(a)-Number(b);
break;
case '*':
b=prompt("Enter Second Value");
Result+=Number(a)*(b);
break;
case '/':
b=prompt("Enter Second Value");
Result+=Number(a)/Number(b);
break;
case 'r':

Result=Math.sqrt(Number(a));
break;
case '%':
per=prompt("Enter the percentage");
Result=(Number(a)/100 )* per;
break;
}
console.log("OUTPUT: "+Result);
